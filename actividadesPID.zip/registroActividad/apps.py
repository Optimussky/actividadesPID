from django.apps import AppConfig


class RegistroactividadConfig(AppConfig):
    name = 'registroActividad'
